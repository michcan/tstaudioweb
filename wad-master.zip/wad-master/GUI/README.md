looper.js is an 8-track delay-based looper.
